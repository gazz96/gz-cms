<?php 

class template extends  database{

	function template_name(){
		$query_str = "SELECT folder FROM templates WHERE aktif='Y'";
		$query = $this->mysql->query($query_str);
		$data = $query->fetch_array();
		return $data['folder'];
	}

	function template_path(){
		return 'gz-content/themes/';
	}

	function get_template(){
		require_once $this->template_path() . $this->template_name() . '/index.php';
	}

}