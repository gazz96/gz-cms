<?php 

//URL
define('BASE_URL', 'http://localhost/project/bpbd/');
define('ADMIN_URL', 'http://localhost/project/bpbd/gz-admin/');

//PATH
define('BASE_PATH', 'project/bpbd/');
define('ADMIN_PATH', 'project/bpbd/gz-admin/');

//ASSETS_URL
define('ASSETS_URL', 'http://localhost/project/bpbd/gz-includes/assets/');

//UPLOAD FOLDER URL
define('UPLOADS_URL', 'http://localhost/project/bpbd/gz-content/uploads/');

define('DEVELOPMENT_DEBUG', false);