<?php 

require_once 'gz-includes/inc.php';

$template = new template();
$template->get_template();