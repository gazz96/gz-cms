var dropdown = document.getElementsByClassName('dropdown')[0];

dropdown.addEventListener('click', function(){
	var child = dropdown.childNodes;
	var childClass = child[3].classList;
	console.log(childClass);
	if(childClass.contains('open')){
		childClass.remove('open');
	}
	else{
		childClass.add('open');
	}
});

var accordion = document.getElementsByClassName('accordion');
var i;

for(i=0; i < accordion.length; i++){
	accordion[i].onclick = function(){
		this.classList.toggle('active');
		var accordionMenu = this.childNodes[3];
		if(accordionMenu.style.maxHeight){
			accordionMenu.style.maxHeight = null;
		}else{
			accordionMenu.style.maxHeight = accordionMenu.scrollHeight + "px";
		}
	}
}