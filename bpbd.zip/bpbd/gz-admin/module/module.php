<?php 

require_once 'kategori.php';
require_once 'users.php';



?>