<?php 
	session_start();
	require_once '../gz-includes/class.database.php';
	require_once '../gz-includes/class.uploads.php';
	require_once '../gz-includes/class.library.php';
	require_once '../config.php';
	require_once 'module/module.php';
	$db = new database;
	$uploads = new uploads;
	$library = new library();
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Administrator Page</title>
	<link rel="stylesheet" href="<?php echo ADMIN_URL . 'css/dashboard.css'; ?>">
	<link rel="stylesheet" href="<?php echo ASSETS_URL . 'css/font-awesome.min.css'; ?>">
	<link rel="stylesheet" href="<?php echo ASSETS_URL . 'css/bootstrap.min.css'; ?>">
	<link rel="stylesheet" href="<?php echo ASSETS_URL . 'css/dataTables.bootstrap.css' ?>">
</head>
<body>

<div class="body-wrapper">
	
	
	<div class="main-wrapper">
		<div class="sidebar-wrapper">
			<div class="sidebar-header">
				<div class="profile">
					<div class="profile-img">
						
					</div>
					<div class="profile-desc">
						<h3>Administrator Page</h3>
					</div>
				</div>
			</div>
			<div class="sidebar-body">
				<div class="sidebar-nav">
					<ul>
						<li><a href="javascript:void(0)" class="active"><span class="fa fa-home"></span> Dashboard</a></li>
						<li class="accordion">
							<a href="javascript:void(0)"><span class="fa fa-pencil"></span> Post</a>
							<ul class="accordion-menu">
								<li><a href="">Tambah baru</a></li>
								<li><a href="">Lihat Semua</a></li>
								<li><a href="">Kategori</a></li>
							</ul>
						</li>
						<li class="accordion">
							<a href="javascript:void(0)"><span class="fa fa-users"></span> Users</a>
							<ul class="accordion-menu">
								<li><a href="?module=users_form">Tambah baru</a></li>
								<li><a href="?module=users_data">Lihat Semua</a></li>
							</ul>
						</li>
						<li><a href="javascript:void(0)"><span class="fa fa-navicon"></span> Menus</a></li>
						<li><a href="javascript:void(0)"><span class="fa fa-eye"></span> Template</a></li>
					</ul>
					
					
					
					
					

				</div>
			</div>
		</div>
	
		<div class="module-wrapper">
			<!-- navbar -->
			<div class="navbar-wrapper">
				<div class="navbar">
					<div class="navbar-header">
						<a href="" class="navbar-brand"></a>
					</div>

					<div class="navbar-collapse">
						<ul class="nav">
							<li><a href=""><span class="fa fa-bell"></span></a></li>
							<li class="dropdown">
								<a href="javascript:void(0)"><span class="fa fa-gear"></span></a>
								<ul class="dropdown-menu">
									<li><a href="">Profile</a></li>
									<li><a href="">Logout</a></li>
								</ul>
							</li>
						</ul>
					</div>
				</div>
			</div>
			<!-- /navbar -->

			<!-- module -->
			<div class="module-box">
				<?php

					$module = isset($_GET['module']) ? $_GET['module'] : false;	
					if(function_exists($module)){
						$module();
					}

				?>
			</div>
			<!-- /module -->
		</div>
	</div>
</div>
<script src="<?php echo ASSETS_URL .'js/jquery-3.2.1.min.js'; ?>"></script>
<script src="<?php echo ASSETS_URL . 'js/bootstrap.js'; ?>"></script>
<script src="<?php echo ADMIN_URL . 'js/adminUI.js'; ?>"></script>
<script src="<?php echo ASSETS_URL . 'js/jquery.dataTables.min.js'; ?>"></script>
<script src="<?php echo ASSETS_URL . 'js/dataTables.bootstrap.min.js'; ?>"></script>
<script>
	$('document').ready(function(){
		+$('#table-users').DataTable({
			"order" : [[0,'desc']]
		});

		var profilTrigger = document.getElementById("profilTrigger");
		var imgInput = document.getElementsByClassName('imgInput')[0];
		profilTrigger.addEventListener('click', function(e){
			e.preventDefault();
			console.log(imgInput);
			imgInput.click();
		});

		imgInput.addEventListener('change', function(){
			var reader = new FileReader();
		    reader.onload = function(e) {
		    	profilTrigger.innerHTML = "<img src='" + e.target.result +"' class='img-responsive'>";
		    }
		    reader.readAsDataURL(this.files[0]);
		});

	});
	
</script>
</body>
</html>